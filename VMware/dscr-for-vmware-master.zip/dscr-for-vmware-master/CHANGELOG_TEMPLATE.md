## Module Name Module Version - Date in the following format: yyyy-mm-dd
### Added
- Description of the new things added for this version. For example new DSC Resources, new Unit and Integration Tests, TestSetup, Configurations, Documentation and so on.

### Changed
- Description of the things updated for this version. For example extending existing DSC Resource, Configuration or Tests (Unit or Integration). All bug fixes should be documented in this section as well. Documentation fixes and updates.

### Removed
- Description of the things removed for this version. For example if a part of the Documentation was removed, or some of the Tests (Unit or Integration) were removed.
